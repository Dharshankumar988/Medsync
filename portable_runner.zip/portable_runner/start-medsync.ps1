# MedSync Portable Runner (PowerShell)
[CmdletBinding()]
param (
    [string]$Mode = "",
    [switch]$Remote,
    [switch]$Headless,
    [switch]$NoNgrok,
    [string]$Port = "",
    [switch]$FollowLogs,
    [switch]$Daemon
)

$ErrorActionPreference = "Stop"
$ScriptPath = $PSScriptRoot
Set-Location -LiteralPath $ScriptPath

# Initialize tracking files
$ContainersFile = Join-Path $ScriptPath ".runner_containers.txt"
$PidsFile = Join-Path $ScriptPath ".runner_pids.txt"
if (-not (Test-Path $ContainersFile)) { New-Item $ContainersFile -ItemType File -Force | Out-Null }
if (-not (Test-Path $PidsFile)) { New-Item $PidsFile -ItemType File -Force | Out-Null }

# Get version
$VERSION = "1.0.4"
if (Test-Path "VERSION") {
    $VERSION = (Get-Content "VERSION" -Raw).Trim()
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "       MEDSYNC PORTABLE RUNNER (v$VERSION)       " -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Execution Target
$Mode = "Full"
Write-Host "`nTarget: Full MedSync Backend" -ForegroundColor Cyan

if ($Remote -or $Headless) {
    Write-Host "Execution Mode: Remote / Headless Server" -ForegroundColor Magenta
} else {
    Write-Host "Execution Mode: Interactive Desktop Runner" -ForegroundColor White
}
Write-Host ""


# 2. Check if Docker is installed and running
if (-not (Get-Command "docker" -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: Docker is not installed or not in your PATH." -ForegroundColor Red
    exit 1
}
try {
    $null = docker info 2>&1
} catch {
    Write-Host "ERROR: Docker daemon is not running." -ForegroundColor Red
    exit 1
}

# 3. Check for .env
$ENV_FILE = Join-Path $ScriptPath ".env"
if (-not (Test-Path -LiteralPath $ENV_FILE)) {
    $legacyEnv = Join-Path $ScriptPath "medsync.env"
    if (Test-Path -LiteralPath $legacyEnv) {
        $ENV_FILE = $legacyEnv
    } elseif (Test-Path -LiteralPath (Join-Path $ScriptPath ".env.example")) {
        Copy-Item (Join-Path $ScriptPath ".env.example") $ENV_FILE
        Write-Host "IMPORTANT: A new .env file was created. Please edit it to add your configuration if needed." -ForegroundColor Red
    } else {
        Write-Host "ERROR: .env file not found." -ForegroundColor Red
        exit 1
    }
}

# Configuration
$BACKEND_REGISTRY_IMAGE = "ghcr.io/dharshankumar988/medsync-backend:latest"
$BACKEND_LOCAL_IMAGE = "medsync-backend:local"
$BACKEND_CONTAINER = "medsync-backend"
$BACKEND_PORT = if ($Port) { [int]$Port } elseif ($env:PORT) { [int]$env:PORT } else { 8000 }


# ==========================================
# FUNCTION: Start-Backend (Option A)
# ==========================================
function Start-Backend {
    param ([string]$EnvOverride = "")
    Write-Host "`n--- Starting Full Backend ---" -ForegroundColor Cyan
    
    $BACKEND_IMAGE = $null
    Write-Host "Checking for existing Backend image..." -ForegroundColor Cyan
    $localReg = docker images -q $BACKEND_REGISTRY_IMAGE
    $localBlt = docker images -q $BACKEND_LOCAL_IMAGE
    
    if ($localReg) {
        $BACKEND_IMAGE = $BACKEND_REGISTRY_IMAGE
        Write-Host "Found registry image locally: $BACKEND_IMAGE" -ForegroundColor Green
    } elseif ($localBlt) {
        $BACKEND_IMAGE = $BACKEND_LOCAL_IMAGE
        Write-Host "Found locally built image: $BACKEND_IMAGE" -ForegroundColor Green
    } else {
        Write-Host "Pulling Backend image from registry..." -ForegroundColor Cyan
        $pullArgs = "pull --platform linux/amd64 $BACKEND_REGISTRY_IMAGE"
        $pullProcess = Start-Process -FilePath "docker" -ArgumentList $pullArgs -NoNewWindow -Wait -PassThru
        if ($pullProcess.ExitCode -eq 0) {
            $BACKEND_IMAGE = $BACKEND_REGISTRY_IMAGE
            Write-Host "`nUsing registry image: $BACKEND_IMAGE" -ForegroundColor Green
        } else {
            # Stale Docker desktop credentials for ghcr.io often cause 'error from registry: denied' on public images.
            # Attempt an unauthenticated pull by logging out of ghcr.io.
            Write-Host "`nInitial pull failed. Clearing stale ghcr.io credentials and retrying unauthenticated..." -ForegroundColor Yellow
            & docker logout ghcr.io 2>&1 | Out-Null
            $retryProcess = Start-Process -FilePath "docker" -ArgumentList $pullArgs -NoNewWindow -Wait -PassThru
            if ($retryProcess.ExitCode -eq 0) {
                $BACKEND_IMAGE = $BACKEND_REGISTRY_IMAGE
                Write-Host "`nUsing registry image: $BACKEND_IMAGE" -ForegroundColor Green
            } else {
                Write-Host "`nRegistry pull failed. Checking for local source build..." -ForegroundColor Yellow
                $RepoRoot = Resolve-Path (Join-Path $ScriptPath "..")
                $df = if (Test-Path "$RepoRoot\apps\backend\Dockerfile.full") { 
                    "$RepoRoot\apps\backend\Dockerfile.full" 
                } elseif (Test-Path "$RepoRoot\apps\backend\Dockerfile") { 
                    "$RepoRoot\apps\backend\Dockerfile" 
                } else { 
                    $null 
                }

                if ($df -and (Test-Path -Path $df) -and (Test-Path -Path "$RepoRoot\apps\backend")) {
                    Write-Host "Building from source: $df..." -ForegroundColor Cyan
                    docker build -t $BACKEND_LOCAL_IMAGE -f "$df" "$RepoRoot"
                    if ($LASTEXITCODE -ne 0) {
                        Write-Host "ERROR: Failed to build backend image." -ForegroundColor Red
                        exit 1
                    }
                    $BACKEND_IMAGE = $BACKEND_LOCAL_IMAGE
                    Write-Host "Using locally built image: $BACKEND_IMAGE" -ForegroundColor Green
                } else {
                    Write-Host "`nERROR: Unable to pull backend image and local source code is not available." -ForegroundColor Red
                    Write-Host "Troubleshooting suggestions:" -ForegroundColor Yellow
                    Write-Host "  1. If running the portable runner, check your network/internet connection." -ForegroundColor Yellow
                    Write-Host "  2. If Docker has stale GitHub tokens, run: docker logout ghcr.io" -ForegroundColor Yellow
                    Write-Host "  3. To build from source, run from within the full MedSync cloned repository." -ForegroundColor Yellow
                    exit 1
                }
            }
        }
    }

    $existing = docker ps -a -q -f "name=^/${BACKEND_CONTAINER}$"
    if ($existing) {
        docker rm -f $BACKEND_CONTAINER > $null
    }

    docker volume create medsync-model-cache > $null

    $runCmd = "docker run --platform linux/amd64 -d --name $BACKEND_CONTAINER -p `"${BACKEND_PORT}:8000`" -v medsync-model-cache:/models --env-file `"$ENV_FILE`""
    if ($EnvOverride) {
        $runCmd += " $EnvOverride"
    }
    $runCmd += " $BACKEND_IMAGE"
    
    Invoke-Expression $runCmd | Out-Null
    $BACKEND_CONTAINER | Out-File -FilePath $ContainersFile -Append -Encoding utf8

    Write-Host "Waiting for backend to become healthy (HTTP 200)..."
    $healthy = $false
    for ($i = 0; $i -lt 60; $i++) {
        Start-Sleep -Seconds 2
        try {
            $response = Invoke-WebRequest -Uri "http://127.0.0.1:${BACKEND_PORT}/health" -UseBasicParsing -ErrorAction SilentlyContinue
            if ($response.StatusCode -eq 200) {
                $healthy = $true
                break
            }
        } catch {}
    }
    
    if (-not $healthy) {
        Write-Host "ERROR: Backend failed health check." -ForegroundColor Red
        docker logs --tail 30 $BACKEND_CONTAINER
        exit 1
    }
    Write-Host "Backend: HEALTHY (Port $BACKEND_PORT)" -ForegroundColor Green

    if ($FollowLogs) {
        Write-Host "`nStreaming backend logs (Ctrl+C to exit log stream)..." -ForegroundColor Cyan
        docker logs -f $BACKEND_CONTAINER
    }
}


# ==========================================
# EXECUTION
# ==========================================

Start-Backend

if (-not $NoNgrok -and -not $Remote -and (Test-Path ".\start-ngrok.ps1")) {
    .\start-ngrok.ps1 -Mode Backend
}

Write-Host "`n========================================================" -ForegroundColor Magenta
Write-Host "          MEDSYNC FULL BACKEND READY                   " -ForegroundColor Magenta
Write-Host "========================================================" -ForegroundColor Magenta
Write-Host "Local / Server Endpoint: http://127.0.0.1:$BACKEND_PORT"

if ($Daemon) {
    Write-Host "`nService is running in background (Daemon mode). Exiting starter process." -ForegroundColor Green
    exit 0
}

Write-Host "`nPress Ctrl+C to stop services or run .\stop-medsync.ps1 in another terminal." -ForegroundColor Yellow
while ($true) { Start-Sleep -Seconds 3600 }
