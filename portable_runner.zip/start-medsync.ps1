# MedSync Backend Startup Script (PowerShell)
$ErrorActionPreference = "Stop"

# Get version
$VERSION = "Unknown"
if (Test-Path "VERSION") {
    $VERSION = Get-Content "VERSION" -Raw
    $VERSION = $VERSION.Trim()
}
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "MedSync Portable Runner v$VERSION" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# 1. Check if Docker is installed
if (-not (Get-Command "docker" -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: Docker is not installed or not in your PATH." -ForegroundColor Red
    Write-Host "Please install Docker Desktop from https://www.docker.com/products/docker-desktop"
    exit 1
}

# 2. Check if Docker is running
try {
    $null = docker info 2>&1
} catch {
    Write-Host "ERROR: Docker daemon is not running." -ForegroundColor Red
    Write-Host "Please start Docker Desktop and try again."
    exit 1
}

# 3. Check for .env
$ScriptPath = $PSScriptRoot
Set-Location -LiteralPath $ScriptPath

$ENV_FILE = Join-Path $ScriptPath ".env"
if (-not (Test-Path -LiteralPath $ENV_FILE)) {
    # Fallback to medsync.env for backward compatibility
    $legacyEnv = Join-Path $ScriptPath "medsync.env"
    if (Test-Path -LiteralPath $legacyEnv) {
        $ENV_FILE = $legacyEnv
        Write-Host "NOTE: Using old medsync.env file. Consider renaming it to .env." -ForegroundColor Yellow
    } else {
        if (Test-Path -LiteralPath (Join-Path $ScriptPath ".env.example")) {
            Write-Host "NOTE: .env file not found. Creating a new one from .env.example..." -ForegroundColor Yellow
            Copy-Item (Join-Path $ScriptPath ".env.example") $ENV_FILE
            Write-Host "IMPORTANT: A new .env file was created. Please edit it to add your configuration if needed." -ForegroundColor Red
        } else {
            Write-Host "ERROR: .env file not found and .env.example is missing in $ScriptPath" -ForegroundColor Red
            exit 1
        }
    }
}

# Simple validation of .env
$envContent = Get-Content $ENV_FILE
if ($envContent -match "SUPABASE_URL=\s*$") {
    Write-Host "WARNING: SUPABASE_URL appears to be empty in $ENV_FILE" -ForegroundColor Yellow
}
if ($envContent -match "GROQ_API_KEY=\s*$") {
    Write-Host "WARNING: GROQ_API_KEY appears to be empty in $ENV_FILE" -ForegroundColor Yellow
}

# 4. (Deprecated) ARM Check - No longer needed as the image is multi-arch
$PLATFORM = ""
# Docker will automatically select the correct architecture (linux/arm64 or linux/amd64)

# 5. Image configuration
$IMAGE_NAME = "ghcr.io/dharshankumar988/medsync-backend:latest"
$CONTAINER_NAME = "medsync-backend"
$PORT = 8000

# 6. Pull image
Write-Host "Skipping image pull to use locally built image..." -ForegroundColor Yellow

# 7. Stop existing containers if running
$existing = docker ps -a -q -f "name=^/medsync-backend$" -f "name=^/medsync_backend$"
if ($existing) {
    Write-Host "Stopping and removing existing container(s)..."
    $existing | ForEach-Object { docker rm -f $_ > $null }
}

# 8. Start container
Write-Host "Starting container $CONTAINER_NAME on port $PORT..."

# Ensure volume exists
docker volume create medsync-model-cache > $null

if ($PLATFORM) {
    docker run -d --name $CONTAINER_NAME -p "${PORT}:8000" -v medsync-model-cache:/models --env-file $ENV_FILE $IMAGE_NAME
} else {
    docker run -d --name $CONTAINER_NAME -p "${PORT}:8000" -v medsync-model-cache:/models --env-file $ENV_FILE $IMAGE_NAME
}

# 9. Open Logs in a separate window
Write-Host "Opening backend logs in a separate window..." -ForegroundColor Cyan
Start-Process cmd -ArgumentList "/c title MedSync Backend Logs & docker logs -f $CONTAINER_NAME"

# 10. Wait for local health check
Write-Host "Waiting for backend to become healthy (HTTP 200)..."
Write-Host "NOTE: First startup may take a few minutes to download AI models in the background." -ForegroundColor Yellow
$healthy = $false
$maxSteps = 150 # 5 minutes with 2-second sleeps
for ($i = 0; $i -lt $maxSteps; $i++) {
    $percent = [math]::min(100, [math]::round(($i / $maxSteps) * 100))
    Write-Progress -Activity "Starting Backend & AI Services" -Status "Please wait... ($percent%)" -PercentComplete $percent
    
    Start-Sleep -Seconds 2
    
    # Check if container crashed
    $status = docker inspect -f '{{.State.Status}}' $CONTAINER_NAME 2>$null
    if ($status -eq "exited" -or $status -eq "dead") {
        Write-Host "`nERROR: The container crashed during startup." -ForegroundColor Red
        break
    }
    
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:${PORT}/health" -UseBasicParsing -ErrorAction SilentlyContinue
        if ($response.StatusCode -eq 200) {
            $healthy = $true
            break
        }
    } catch {
        # ignore errors while waiting
    }
}
Write-Progress -Activity "Starting MedSync Backend" -Completed

if (-not $healthy) {
    if ($status -eq "exited" -or $status -eq "dead") {
        Write-Host "`nDocker container crashed. Recent logs:" -ForegroundColor Red
    } else {
        Write-Host "`nWARNING: Backend did not report healthy within 5 minutes." -ForegroundColor Red
        Write-Host "Docker container status:"
        docker ps -f "name=^/medsync-backend$" -f "name=^/medsync_backend$"
        Write-Host "`nRecent logs:"
    }
    docker logs --tail 30 $CONTAINER_NAME
    Write-Host "`nTroubleshooting:"
    Write-Host "- Verify your .env variables (especially Database connection)."
    Write-Host "- Ensure port 8000 is not blocked or in use by another app."
    exit 1
}

Write-Host "Backend: HEALTHY" -ForegroundColor Green

# 10. Start Ngrok Tunnel if present
if (Test-Path ".\start-ngrok.ps1") {
    .\start-ngrok.ps1
} else {
    Write-Host "`n=== STATUS ===" -ForegroundColor Green
    Write-Host "Docker: READY"
    Write-Host "Image:  READY"
    Write-Host "Container: RUNNING"
    Write-Host "Health: OK"
    Write-Host "MedSync backend is READY on http://localhost:${PORT}." -ForegroundColor Green
    Write-Host "================`n"
}
